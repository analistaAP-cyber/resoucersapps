-- ============================================================  
--   Objetivo:  Creaci�n Campo Periodo Facturaci�n
--                                                      
--   Autor:     SEVEN-ERP                   
--   Modulo:    Facturaci�n
--   Motor BD:  SQL SERVER                                  
--   Caso:      888034
-- ============================================================

ALTER TABLE FA_IMPOR ADD FAC_FEPF DATETIME
GO

EXECUTE SP_ADDEXTENDEDPROPERTY 'COMENTARIO','Periodo Facturaci�n','USER',DBO,'TABLE','FA_IMPOR','COLUMN','FAC_FEPF'
GO

-- GUARDAR REGISTRO EN TABLA GN_BILOG
INSERT INTO GN_BILOG(BIL_VERS,BIL_CODI,BIL_DESC,BIL_USUA,BIL_FECH)
	VALUES('STD',8284,'Creaci�n Campo Periodo Facturaci�n',SUSER_SNAME(), GETDATE()) 
GO
